def calc_shipping():
    print("Shipping")
    pass


def calc_taxt():
    print("Taxt")
    pass
